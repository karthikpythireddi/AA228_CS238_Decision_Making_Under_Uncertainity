using Graphs
using Printf
using CSV
using DataFrames

"""
    write_gph(dag::DiGraph, idx2names, filename)

Takes a DiGraph, a Dict of index to names and a output filename to write the graph in `gph` format.
"""
function write_gph(dag::DiGraph, idx2names, filename)
    open(filename, "w") do io
        for edge in edges(dag)
            @printf(io, "%s,%s\n", idx2names[src(edge)], idx2names[dst(edge)])
        end
    end
end


function compute(infile, outfile)

    # WRITE YOUR CODE HERE
    # FEEL FREE TO CHANGE ANYTHING ANYWHERE IN THE CODE
    # THIS INCLUDES CHANGING THE FUNCTION NAMES, MAKING THE CODE MODULAR, BASICALLY ANYTHING
    csv_file = CSV.File(infile)
    df = DataFrame(csv_file)
    variable_names = names(df)
    println(variable_names)
    data = Matrix(df)
    data_T = transpose(data)



    G = SimpleDiGraph(5)
    add_edge!(G, 1, 2)
    add_edge!(G, 3, 4)
    add_edge!(G, 5, 6)
    add_edge!(G, 1, 4)
    add_edge!(G, 5, 4)

    println(bayesianscore(variable_names, G, data_T))

end



function prior(variable_names, G)
    n = length(variable_names)
    alpha = zeros(n, n)
    r = [variable_names[i].r for i in 1:n]
    q = [prod([r[j]] for j in inneighbors(G, i)) for i in 1:n]
    return [ones(q[i], r[i]) for i in 1:n]
end

function statistics(variable_names, G, data_T)
    n = size(data_T, 1)
    r = [variable_names[i].r for i in 1:n]
    q = [prod([r[j]] for j in inneighbors(G, i)) for i in 1:n]
    M = [zeros(q[i], r[i]) for i in 1:n]
    for o in eachcol(D)
        for i in 1:n
            k = o[i]
            parents = inneighbors(G, i)
            j = i
            if !isempty(parents)
                j = sub2ind(r[parents], o[parents])
            end
            M[i][j, k] += 1.0
        end
    end
    return M
end

function bayesianscore_component(M,alpha)

    p = sum(loggamma.(alpha + M))
    q = sum(loggamma.(alpha))

    r = sum(loggamma.sum(alpha, dims = 2))
    s = sum(loggamma.(sum(alpha, dims = 2) + sum(M, dims = 2)))

    return p - q + r - s
end

function bayesianscore(variable_names, G, data_T)
    n = length(variable_names)
    M = statistics(variable_names, G, data_T)
    alpha = prior(variable_names, G)
    return sum(bayesianscore_component.(M[i], alpha[i]) for i in 1:n)
end



# if length(ARGS) != 2
#     error("usage: julia project1.jl <infile>.csv <outfile>.gph")
# end

# inputfilename = ARGS[1]
# outputfilename = ARGS[2]

inputfilename = "/home/karthikpythireddi/Stanford_Classes/AA228/AA228-CS238-Student/project1/example/example.csv"
outputfilename = "/home/karthikpythireddi/Stanford_Classes/AA228/AA228-CS238-Student/project1/example/example.gph"
compute(inputfilename, outputfilename)
